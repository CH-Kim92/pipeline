import { useNavigate, useParams } from "react-router-dom";
import React, {useState, useContext, useEffect} from "react"
import axios from "axios";
import classes from "./pagesCss/RequestSend.module.css"
import AuthContext from "../Auth/authentication/AuthContext";
import logo from "../components/Images/logo.svg";

const RequestSendPage = () => {
  let {user} = useContext(AuthContext);
  const {id} = useParams();

  const[houses, setHouses] = useState([])
  const[swapin, setSwapin] = useState('')
  const[swapout, setSwapout] = useState('')
  const[explain, setExplain] = useState('')
  const[loading, setLoading] = useState(false)

  const navigate = useNavigate();
  
  useEffect(()=> {
    axios.get(`http://127.0.0.1:8000/housedata/${id}/`)
    .then((res)=> {
      console.log(res)
      setHouses(res.data)
    })
  },[])

  let handleSubmit = (e) => {
    e.preventDefault();
    let redata = new FormData();
    console.log(redata)
    redata.append("user_id",user.user_id)
    redata.append("HouseData_id",houses.id)
    redata.append("swapin",swapin)
    redata.append("swapout",swapout)
    redata.append("explain",explain)
    redata.append("status", 0)
    axios.post("http://localhost:8000/request/",redata,{
      headers:{
        "content-type":"multipart/form-data"
      }
    })
    .then((res) => {
      console.log(res.data)
      navigate('/');
    })
    .catch((err) => console.log(err))
  }

  return(
    <div>
         <div className={classes.contactwrap}>
            <dl className={classes.dl}>
              <h3>To.. {houses.title}</h3>
              <dd className={classes.timesbox}>
                Swap Window : {houses.swapIn} ~ {houses.swapOut}
              <dd className={classes.prebox}>{houses.description}</dd>
              </dd>
            </dl>
          </div>
          <div className={classes.alertpopup}>
            <div className={classes.alertbox}>
              <div className={classes.logobox}>
                <img src={logo} alt="swaperty logo"></img>
              </div>
              <ul className={classes.timeselectbox}>
                <li>
                  <div className={classes.inputbox}>
                    <label>Swap In</label>
                    <input
                      type="text"
                      id="swapin"
                      placeholder="Swap In date"
                      pattern="[0-9]{2}.[0-9]{2}.[0-9]{4}"
                      value={swapin}
                      onChange={e => setSwapin(e.target.value)}                   
                      required
                    />

                    <small>Format:dd.mm.yyyy</small>
                  </div>
                </li>
                <li>
                  <div className={classes.inputbox}>
                    <label>Swap Out</label>
                    <input
                      type="text"
                      id="swapout"
                      placeholder="Swap Out date"
                      pattern="[0-9]{2}.[0-9]{2}.[0-9]{4}"
                      value={swapout}
                      onChange={e => setSwapout(e.target.value)}
                      required
                    />
                    <small>Format:dd.mm.yyyy</small>
                  </div>
                </li>
              </ul>
              <div className={classes.textareabox}>
                <textarea
                  type="text"
                  id="explain"
                  placeholder="Why do you want to swap ?"
                  value={explain}
                  onChange={e => setExplain(e.target.value)}
                  required
                />
              </div>
              <div className={classes.btnarea}>
                <button onClick={handleSubmit}>Send Request</button>
              </div>
            </div>
          </div>
      </div>

  )

}

export default RequestSendPage